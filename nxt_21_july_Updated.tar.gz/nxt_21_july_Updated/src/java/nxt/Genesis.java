/*
 * Copyright © 2013-2016 The Nxt Core Developers.
 * Copyright © 2016-2017 Jelurida IP B.V.
 *
 * See the LICENSE.txt file at the top-level directory of this distribution
 * for licensing information.
 *
 * Unless otherwise agreed in a custom licensing agreement with Jelurida B.V.,
 * no part of the Nxt software, including this file, may be copied, modified,
 * propagated, or distributed except according to the terms contained in the
 * LICENSE.txt file.
 *
 * Removal or modification of this copyright notice is prohibited.
 *
 */

package nxt;

public final class Genesis {

    public static final long GENESIS_BLOCK_ID = Long.parseUnsignedLong("8428255625200866724");
    public static final long CREATOR_ID = Long.parseUnsignedLong("9428819579498199832");
    public static final byte[] CREATOR_PUBLIC_KEY = {
          -48, -95, 82, 121, -26, -87, 119, 41, 126, 102, 13, -31, -35, -39, -115, 44, 63, -75, -85, 49, 76, 5, 122, -39, 110, -97, -18, 29, -41, 34, -16, 97  
    };

    public static final long[] GENESIS_RECIPIENTS = {
            Long.parseUnsignedLong("1673962284572794587"),
            Long.parseUnsignedLong("10255282365752841024")
    };


    public static final int[] GENESIS_AMOUNTS = {
            16000000,
            5000000
    };

    public static final byte[][] GENESIS_SIGNATURES = {
            {122, 30, 27, -79, 32, 115, -104, -28, -53, 109, 120, 121, -115, -65, -87, 101, 23, 10, 122, 101, 29, 32, 56, 63, -23, -48, -51, 51, 16, -124, -41, 6, -71, 49, -20, 26, -57, 65, 49, 45, 7, 49, -126, 54, -122, -43, 1, -5, 111, 117, 104, 117, 126, 114, -77, 66, -127, -50, 69, 14, 70, 73, 60, 112},
            {104, -117, 105, -118, 35, 16, -16, 105, 27, -87, -43, -59, -13, -23, 5, 8, -112, -28, 18, -1, 48, 94, -82, 55, 32, 16, 59, -117, 108, -89, 101, 9, -35, 58, 70, 62, 65, 91, 14, -43, -104, 97, 1, -72, 16, -24, 79, 79, -85, -51, -79, -55, -128, 23, 109, -95, 17, 92, -38, 109, 65, -50, 46, -114}
    };

    public static final byte[] GENESIS_BLOCK_SIGNATURE = new byte[]{
            105, -44, 38, -60, -104, -73, 10, -58, -47, 103, -127, -128, 53, 101, 39, -63, -2, -32, 48, -83, 115, 47, -65, 118, 114, -62, 38, 109, 22, 106, 76, 8, -49, -113, -34, -76, 82, 79, -47, -76, -106, -69, -54, -85, 3, -6, 110, 103, 118, 15, 109, -92, 82, 37, 20, 2, 36, -112, 21, 72, 108, 72, 114, 17
    };

    private Genesis() {} // never

}
